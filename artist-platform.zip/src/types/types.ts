export interface ICheckbox {
  name: string;
  checked: boolean;
}
