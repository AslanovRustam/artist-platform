import React from "react";

type Props = {};

export default function SingleArtist({}: Props) {
  return <div>SingleArtist</div>;
}
